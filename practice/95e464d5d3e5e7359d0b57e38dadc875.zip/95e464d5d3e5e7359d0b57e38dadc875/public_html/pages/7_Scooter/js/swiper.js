const swiper = new Swiper(".swiper", {
	spaceBetween: 40,
	speed: 800,
	loop: true,
	centeredSlides: true,
	slidesPerView: "auto",
});
