<?php
echo var_dump($_POST);